<!DOCTYPE html>
<html>

<head>
    <title>Post Information</title>
    <meta charset="UTF-8">
</head>

<body>
    <div>
        <label id="lblHelloUser">Hello INSERT NAME HERE!</label>
        <br>
        <label id="LblLogout">Logout</label>
        <h2>Member Posts</h2>
    </div>


    <form id="frmAboutMe" action="/" method="post">
        <h3>About Me</h3>
        <table>

            <tr>
                <td>
                    <label id="lblPurpose">Purpose:</label>

                </td>

                <td>
                    <select>
                        <option value="pooler">Pooler</option>
                        <option value="lifter">Lifter</option>
                        </select>
                </td>
            </tr>

            <tr>
                <td>
                    <label id="lblName">Name:</label>
                </td>

                <td>
                    <input type="text" id="txtMemberName" name="memberName">
                </td>
            </tr>

            <tr>
                <td>
                    <label id="lblGender">Gender:</label>
                </td>

                <td>
                    <select>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="other">Other</option>
                        </select>
                </td>
            </tr>

            <tr>
                <td>
                    <label id="lblAge">Age:</label>

                </td>

                <td>
                    <select>
                        <option value="17-30">17-30</option>
                        <option value="30-50">30-50</option>
                        <option value="51+">51+</option>
                    </select>
                </td>
            </tr>

            <tr>
                <td>
                    <label id="lblProfession">Profession:</label>

                </td>
                <td>
                    <input type="text" id="txtProfession" name="profession">
                </td>

            </tr>
            <tr>
                <td>
                    <br>
                    <label id="lblImage">Image(s):</label>

                </td>
                <td>
                    <br>
                    <input type="file" size="40" name="uploadImage"/>

                </td>

            </tr>
            <tr>
                <td>

                </td>
                <td>
                    <br>
                    <input type="submit" value="Save" name="aboutMeSave">

                </td>

            </tr>
        </table>
    </form>

    <form id="frmCommunteJourney" action="/" method="post">
        <h2>Commute Journey</h2>
        <table>

            <tr>
                <td>
                    <label id="lblStartingPoint">Starting Point:</label>

                </td>

                <td> <input type="text" id="txtStartingPoint" name="startingPoint">
                </td>
            </tr>

            <tr>
                <td>
                    <label id="lblDestination">Destination:</label>
                </td>

                <td>
                    <input type="text" id="txtDestinaton" name="destination">
                </td>
            </tr>

            <tr>
                <td>
                    <label id="lblTravelTime">Travel Time:</label>
                </td>

                <td>
                    <input type="text" id="txtTravelTime" name="travelTimen">

                </td>
            </tr>

            <tr>
                <td>
                    <label id="lblDays">Days:</label>

                </td>

                <td>
                    <input type="checkbox" name="mon" value="">Mon
                    <input type="checkbox" name="tue" value="">Tue
                    <input type="checkbox" name="wed" value="">Wed
                    <input type="checkbox" name="thur" value="">Thur
                    <input type="checkbox" name="fri" value="">Fri
                    <input type="checkbox" name="sat" value="">Sat
                    <input type="checkbox" name="sun" value="">Sun


                </td>
            </tr>

            <tr>
                <td>
                    <label id="lbl">Profession:</label>

                </td>
                <td>
                    <input type="text" id="txtProfession" name="profession">
                </td>

            </tr>
            <tr>
                <td>

                </td>
                <td>
                    <input type="submit" value="Add Journey" name="aboutMeSave">

                </td>

            </tr>
        </table>
        <br>
        <div>
            <input type="submit" value="Add Another Journey" name="addAnotherJourney">
        </div>


    </form>
</body>


</html>
