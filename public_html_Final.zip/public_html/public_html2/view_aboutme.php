<?php  
ob_start();
session_start();  
?>
<!DOCTYPE html>
<html>

<head>
    <title>Post Information</title>
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="style.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
     <div class="inside"> 
     <div class="inn">
    <a href="index.php">Home</a>
    <a href="logout.php">Logout</a>
    <div>
        <br/>
         <?php if(isset($_SESSION['userAdded'])){ ?>
                <a href="view_login_successful.php">Back</a>
        <br/>
        <label id="lblHelloUser">Logged in: <?php echo $_SESSION["userAdded"];?></label>
        
        <h2>About Me</h2>
    </div>


    <form id="frmAboutMe" action="model_aboutme.php" method="post">
        <table>
            <tr>
                <td>
                    <label id="lblPurpose">Purpose:</label>
                </td>

                <td>
                    <?php 
                        if($_SESSION["empty"]==0){ 
                            ?>
                            <select name="lblPurposeC">
                            <option value="pooler">Pooler</option>
                            <option  value="lifter">Lifter</option>
                            </select> 
                         <?php } ?>
                    <?php 
                        if(isset($_SESSION["purpose"]) && $_SESSION["purpose"] == "lifter" && $_SESSION["empty"]!=0){ 
                            ?>
                            <select name="lblPurposeA">
                            <option value="pooler">Pooler</option>
                            <option selected = "selected" value="lifter">Lifter</option>
                            </select> 
                         <?php } ?>                      
                        <?php 
                        if(isset($_SESSION["purpose"]) && $_SESSION["purpose"] == "pooler" && $_SESSION["empty"]!=0){ 
                            ?>
                            <select name="lblPurposeB">
                            <option selected = "selected" value="pooler">Pooler</option>
                            <option  value="lifter">Lifter</option>
                            </select> 
                         <?php } ?>                    
                        
                </td>
            </tr>        
            <tr>
                <td>
                    <label id="lblName">Name:</label>
                </td>
                <td>
                    <?php   
                    if($_SESSION["empty"]==0){?>
                        <input type="text" id="txtMemberName" name="memberName">                  
                    <?php }?>
                    
                    <?php 
                    if(isset($_SESSION["name"]) && $_SESSION["empty"]!=0 ){ ?>
                    <input type="text" id="txtMemberNameDefault" value="<?php echo $_SESSION["name"]; ?>">
                    <?php } ?>   
                </td>
            </tr>
            <tr>
                <td>
                    <label id="lblGender">Gender:</label>
                </td>

                <td>
                    <?php 
                    if($_SESSION["empty"]==0){
                    ?>
                        <select name="lblGender">
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="other">Other</option>
                        </select>
                    <?php } ?>
                    <?php 
                    if(isset($_SESSION["gender"]) && $_SESSION["gender"]== "male" && $_SESSION["empty"]!=0){
                    ?>
                         <select name="lblGenderA">
                                <option selected = "selected" value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                        </select>
                    <?php }?>
                    <?php 
                    if(isset($_SESSION["gender"]) && $_SESSION["gender"]== "female" && $_SESSION["empty"]!=0){
                    ?>
                        <select name="lblGenderB">
                                <option value="male">Male</option>
                                <option selected = "selected" value="female">Female</option>
                                <option value="other">Other</option>
                        </select>
                    <?php }?>
                    <?php 
                    if(isset($_SESSION["gender"]) && $_SESSION["gender"] == "other" && $_SESSION["empty"]!=0){
                    ?>
                        <select name="lblGenderC">
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option selected = "selected" value="other">Other</option>
                        </select>
                    <?php }?>
        
                </td>
            </tr>
            <tr>
                <td>
                    <label id="lblAge">Age:</label>
                </td>
                <td>
                <?php 
                    if(isset($_SESSION["age"]) && $_SESSION["age"]=="17-30" && $_SESSION["empty"]!=0){?>
                        <select name="lblAge">
                        <option selected = "selected" value="17-30">17-30</option>
                        <option value="30-50">30-50</option>
                        <option value="51+">51+</option>
                        </select>
                <?php }?>
                <?php 
                    if(isset($_SESSION["age"]) && $_SESSION["age"]=="30-50" && $_SESSION["empty"]!=0){?>
                        <select name="lblAgeA">
                        <option value="17-30">17-30</option>
                        <option selected = "selected" value="30-50">30-50</option>
                        <option value="51+">51+</option>
                        </select>
                <?php }?>
                <?php 
                    if(isset($_SESSION["age"]) && $_SESSION["age"]=="50+" && $_SESSION["empty"]!=0){?>
                        <select name="lblAgeB">
                        <option value="17-30">17-30</option>
                        <option value="30-50">30-50</option>
                        <option selected = "selected" value="51+">51+</option>
                        </select>
                <?php }
                    if($_SESSION["empty"]==0){?>
                       <select name="lblAgeC">
                        <option value="17-30">17-30</option>
                        <option value="30-50">30-50</option>
                        <option value="51+">51+</option>
                        </select>
                    <?php } ?>        
                </td> 
            </tr>
            <tr>
                <td>
                    <label id="lblProfession">Profession:</label>
                </td>
                <td>
                   <?php
                    if(isset($_SESSION["profession"])&& $_SESSION["empty"]!=0){?>
                    <input type="text" id="txtProfessionDefault" value="<?php echo $_SESSION["profession"]; ?>">
                     <?php } ?>
                    <?php
                        if($_SESSION["empty"]==0){?>
                            <input type="text" id="txtProfession" name="profession">
                     <?php }?>
                </td>
            </tr>
             <tr>
                <td>
                    <br>
                    <label id="lblImage">Image(s):</label>
                </td>
                <td>
                    <br>
                    <input type="file" size="40" name="uploadImage"/>
                </td>
            </tr>
            <tr>
                <td>
                </td>
                <td>
                    <br>
                    <input type="submit" value="Save" name="aboutMeSave" <?php $_SESSION["update"]="true";?>>
                </td>
            </tr>
        </table>
    </form>
    <?php }else {
            header('location: view_login.php');
            exit();
    
        }?>
    </div>
        </div>
</body>
</html>