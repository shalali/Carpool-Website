<!DOCTYPE html>
<html>

<head>
    <title>Login Successful</title>
    <meta charset="UTF-8">
</head>

<body>

    <!--Registration Process</h1>-->
    <div>
        <h2>Welcome INSERTNAME</h2>
        <a title="Click her to post info about yourself & your intended journeys" href = "" id="lblPostInfo">Post Information</a>
        <br>
        <a href= "" id="lblEditInfo">Edit Information</a>   
    </div>

</body>


</html>
