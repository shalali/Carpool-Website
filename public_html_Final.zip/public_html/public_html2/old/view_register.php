<!DOCTYPE html>
<html>

<head>
    <title>Register</title>
    <meta charset="UTF-8">

    <script type="text/javascript">
        function Validate() {
            var password = document.getElementById("txtPassword").value;
            var confirmPassword = document.getElementById("txtConfirmPassword").value;
            if (password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }
            return true;
        }

    </script>

    <script type="text/javascript">
        document.getElementById("btnRegister").onclick = function() {
            location.href = "view_verify.php";
        };

    </script>

</head>

<body>
    <a href="index.php">Home</a>

    <form id="frmRegister" action="/model_register.php" method="post">
        <div>
           <?php// echo $_SESSION['username']; ?>
            <h2>Register</h2>
            <label id="lblName">Username:</label>
            <input type="text" id="txtName" name="username"
            value="<?php if(!empty($_SESSION['username'])) {echo $_SESSION['username'];} ?>"
              minlength="5" maxlength="12" required>
        </div>

        <div>
            <label id="lblPassword">Password:</label>
            <input type="password" id="txtPassword" name="password" minlength="8" required>
        </div>

        <div>
            <label id="lblConfirmPassword">Re-enter Password:</label>
            <input type="password" id="txtConfirmPassword" name="confirmPassword" required>
        </div>

        <div>
            <label id="email">Email:</label>
            <input type="email" id="txtEmail" name="email">
        </div>

        <div>
            <img src="/model_captcha.php?rand=<?php echo rand(); ?>" id="captchaimg">
            <br>
            <label id="lblcaptcha">Enter the code above here :</label>
            <input type="text" id="txtCaptchaCode" name="vercode">

            <input id="btnRegister" type="submit" value="Register" name="register" onclick="return Validate()">
        </div>

    </form>

    <div id="errors">
        <?php
        if(!empty($_SESSION['username'])){
                echo 'Username taken.';
                unset($_SESSION['usernmae']);
            }
        ?>
    </div>


</body>


</html>
