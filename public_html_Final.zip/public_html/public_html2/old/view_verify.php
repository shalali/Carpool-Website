<!DOCTYPE html>
<html>

<head>
    <title>Verify</title>
    <meta charset="UTF-8">
</head>

<body>
    
    <!--Registration Process</h1>-->
    <form id="frmRegister" action="/" method="post">
        <div>
            <h2>Verify Account</h2>
            <label id="lblCode">Enter activation code:</label>
            <input type="text" id="txtCode" name="code">
            <input type="submit" value="Register" name="register">
        </div>
    </form>

</body>


</html>
