<!DOCTYPE html>
<html lang="en-GB">
<head>
    <title>Untitled Document</title>
    <meta charset="UTF-8">
   </head>
<body>
<h1>Home page</h1>
<div>
<a href="view_login.php">Login</a>
<br>
<a href="view_register.php">Register</a>
</div>
<div>
<h2>Member Search</h2>
</div>

</body>
</html>
