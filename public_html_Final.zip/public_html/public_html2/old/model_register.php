<?php
ob_start();
session_start();

//validation
    //check username
    //check email
    //checl captcha

/*
if ($_POST["vercode"] != $_SESSION["vercode"] OR $_SESSION["vercode"]=='')  { 
     echo  '<strong>Wrong captcha code. Try again.</strong>'; 
} else { 
     // add form data processing code here 
     echo  '<strong>Verification successful.</strong>';
}
*/

//$host = "mysql.cms.gre.ac.uk";
//$username = "st8511x";
//$password = "tina2";

function db_connect(){
$dbname = "mdb_st8511x";

$host = "localhost";
$username = "root";
$password = "";




//est. connection
$conn = mysqli_connect($host, $username, $password, $dbname);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . $conn->connect_error);
} 
    
echo "Connected successfully";
    return $conn;
}


?>


    <br>
<?php

if(isset($_POST['register']) && isset($_POST['username']) && isset($_POST['password']) && isset($_POST['email'])){ // checks if the form was submitted to the controller
    $user = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    if($user){
        if(checkUsernameExists($user)){
        $_SESSION['username'] = $user;
        header('location: view_register.php');
        }
        else{
           
        }
    }
}

//checkUsername();
//check username exists
function checkUsernameExists($user){
    $conn = db_connect();
    $sql = "SELECT * FROM user WHERE username = '".$user."'";
    $result = mysqli_query($conn,$sql);
    if(mysqli_num_rows($result) >= 1){
        //echo "Username taken. ";
        return true;
 
       }
        mysqli_close($conn);
        return false; 
    }//check username




/*

//check email
$sql = "SELECT * FROM user WHERE email = '".$email."'";
$result = mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>=1)
       {
        echo "Email ID taken. ";
       }


$sql = "INSERT INTO user (username, password, email) VALUES ('". $user. "','". $password . "','".$email."')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
    


    
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
    
        
function incrementalHash($len = 5){
  $charset = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
  $base = strlen($charset);
  $result = '';

  $now = explode(' ', microtime())[1];
  while ($now >= $base){
    $i = $now % $base;
    $result = $charset[$i] . $result;
    $now /= $base;
    }//loop
  return substr($result, -5);
    }//func

    $code=incrementalHash();

$sqlo = "INSERT INTO user (code) VALUES ('".$code."')";
mysqli_query($conn,$sqlo);  
    
    
        //header('Location: view_verify.php');



    
//email    
//$to = "st8511x@greenwich.ac.uk";
$to = $email;
$subject = "Activation Code";
$txt = "hi";
$headers = "From: donotreply@greengreenwich.org" . "\r\n";
//"CC: somebodyelse@example.com";

mail($to,$subject,$txt,$headers);


//close connection
mysqli_close($conn);




 



//exit(0);*/

?>
