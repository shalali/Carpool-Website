<!DOCTYPE html>
<html>

  <head>
    <title>Login</title>
    <meta charset="UTF-8">
  </head>

  <body>
<a href="index.php">Home</a>

    <form id="frmRegister" action="/" method="post">
      <div>
        <h2>Login</h2>
        <label id="lblName">Username:</label>
        <input type="text" id="txtName" name="username">
      </div>

      <div>
        <label id="lblPassword">Password:</label>
        <input type="password" id="txtPassword" name="password">
        <br>
        <input type="submit" value="Login" name="login">
      </div>


    </form>
  </body>


</html>
