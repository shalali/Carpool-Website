<?php ob_start(); session_start(); ?>
<!DOCTYPE html>
<html>

<head>
    <title>Post Information</title>
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="style.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
     <div class="inside">
        <div class="inn">
    <div>
    <a href="index.php">Home</a>
        <a href="logout.php">Logout</a>
    <?php if(isset($_SESSION['userAdded'])){ ?>
        <br/><br/>
        <a href="view_login_successful.php">Back</a>
        <br/>
        <label id="lblHelloUser">Logged in: <?php echo $_SESSION['userAdded']; ?></label>

        <h2>Communte Journeys</h2>
    </div>
    <form id="frmCommunteJourney" action="model_journey.php" method="post">
        <table>
            <tr>
                <td>
                    <label id="lblStartingPoint">Starting Point:</label>
                </td>
                <td> <input type="text" id="txtStartingPoint" name="startingPoint" required>
                </td>
            </tr>            <tr>
                <td>
                    <label id="lblDestination">Destination:</label>
                </td>
                <td>
                    <input type="text" id="txtDestinaton" name="destination" required>
                </td>
            </tr>
            <tr>
                <td>
                    <label id="lblTravelTime" >Travel Time:</label>
                </td>
                <td>
                    <input type="text" id="txtTravelTime" name="travelTime" required>
                </td>
            </tr>
            <tr>
                <td>
                    <label id="lblDays">Days:</label>
                </td>
                <td>
                    <input type="checkbox" name="check_list[]" value="Monday">Mon
                    <input type="checkbox" name="check_list[]" value="Tuesday">Tue
                    <input type="checkbox" name="check_list[]" value="Wednesday">Wed
                    <input type="checkbox" name="check_list[]" value="Thursday">Thur
                    <input type="checkbox" name="check_list[]" value="Friday">Fri
                    <input type="checkbox" name="check_list[]" value="Saturday">Sat
                    <input type="checkbox" name="check_list[]" value="Sunday">Sun
                </td>
            </tr>
        
            <tr>
                <td>

                </td>
                <td>
                    <input type="submit" value="Add Journey" name="aboutMeSave">

              </td>
            </tr>
        </table>
        <br>

    </form>
    <?php }else {
            header('location: view_login.php');
            exit();
    
        }?>
            <h2>My Posts</h2><br>
            
             <?php if(isset($_POST["uppost"])){
    if(update_post_details($_POST['st'],$_POST['en'],$_POST['da'],$_POST['ti'])){
        echo 'UPDATED SUCCESSFULLY';
    }
}
            getmyposts(); ?>
          </div>
        </div>
   
</body>


</html>

<?php 
function db_connect(){

    $dbname = "mdb_st8511x";
   
    $host = "mysql.cms.gre.ac.uk";
    $username = "st8511x";
    $password = "tina2";

    //$host = "localhost";
    //$username = "root";
    //$password = "";

    //est. connection
    $conn = mysqli_connect($host, $username, $password, $dbname);

    
    // Check connection
    if (!$conn) {
        die("Connection failed: " . $conn->connect_error);
    } 
    
    //echo "Connected successfully";    
    return $conn;
}//db_connect
function update_post_details($start,$end,$days,$time){
    $conn = db_connect();
    $purpose = mysqli_real_escape_string($conn,$start);
     $name = mysqli_real_escape_string($conn,$end);
     $gender = mysqli_real_escape_string($conn,$days);
     $age = mysqli_real_escape_string($conn,$time);
    $sql = "UPDATE `journey` SET `start` = '".$purpose."', `end` = '".$name."', `days` = '".$gender."', `time` = '".$age."'";   
    mysqli_query($conn,$sql);
if(mysqli_affected_rows($conn) > 0){
        return true;
    }
    else{
        return false;
    }
    
    
}
function getmyposts(){
    $conn = db_connect();
    $sql = "SELECT * FROM journey WHERE username = '".$_SESSION['userAdded']."'";
    $results = mysqli_query($conn,$sql);
    while($row = $results->fetch_assoc()){
            $rows[] = $row;
        
        }
        foreach($rows as $row){
            echo '<form method="post" action="view_member_post.php">';
            echo "Start: <input name=\"st\" type=\"text\" value=\"".$row['start']."\"/><br>";
            echo "End: <input name=\"en\" type=\"text\" value=\"".$row['end']."\"/><br>";
            echo "day: <input name=\"da\"type=\"text\" value=\"" .$row['days']."\"/><br>";
            echo "time: <input name=\"ti\" type=\"text\" value=\"".$row['time']."\"/><br>";
            echo '<input type="submit" value="update" name="uppost"></form>';

        }
       
    
    
}

?>
